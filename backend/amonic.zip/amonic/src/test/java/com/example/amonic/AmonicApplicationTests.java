package com.example.amonic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmonicApplicationTests {

	@Test
	void contextLoads() {
	}

}
