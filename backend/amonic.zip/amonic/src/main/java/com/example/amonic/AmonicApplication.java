package com.example.amonic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmonicApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmonicApplication.class, args);
	}

}
